package main;


public class Index {

	public void indexOfC(String text)
    {
      int[] letters = new int[26];
      char c;
      int hlp1=0;
      double count=0, dcount=0;
      double ic;
      for(int i=0;i<26;i++){
        letters[i]=0;
      }
      
      int lngt=text.length();
      
      for(int i=0;i<lngt;i++)
      {
        c=text.charAt(i);
        hlp1=c-65;
        
        letters[hlp1]+=1;
      }
      
      
      for(int i=0;i<26;i++){
        if(letters[i]>1){
          hlp1=letters[i];
          
          dcount+=hlp1*(hlp1-1);
        }
      }
      
      count=lngt*(lngt-1);
      
      ic=dcount/count;
      System.out.println(ic);
    }
}
