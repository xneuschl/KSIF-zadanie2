package main;

public class Member {
	public int rownum;
	public int colnum;
	public boolean w_sw;
	public boolean r_sw;
	public int[] shuffle;

}
