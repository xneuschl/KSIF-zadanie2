package main;

import java.util.Scanner;
import java.io.*;

public class Main {

	public static void main(String[] args) throws FileNotFoundException{
		
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = new Scanner(System.in);
		System.out.println("Zadajte ZT:");
        String input = scan1.nextLine();
        System.out.println("Zadajte maxim�lnu d�ku k���a:");
        int maxkey=scan2.nextInt();

        BFA bfa = new BFA();
        bfa.basic(input, maxkey); 
        
	}

}
