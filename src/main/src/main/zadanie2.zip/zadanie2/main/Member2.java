package main;

public class Member2 {
	public int rownum;     //pocet riadkov
	public int colnum;     //pocet stlpcov
	public boolean w_sw;   //sposob zapisovania: T = po riadkoch, F = po stlpcch
	public boolean r_sw;   //sposob citania: T = po riadkoch, F = po stlpcch
	public boolean r_c;    //permutacia - T = stlpcov, F = riadkov
	public int[] shuffle;  //permutacia stlpcov
	public String input;   //zasifrovany text
	public int length;     //dlzka zasifrovaneho textu

}
