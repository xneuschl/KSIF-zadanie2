package main;

import java.util.*;

public class helpers {
	

	
	public String[] shuffleC(int[] arr, String[] input)
	{
		String[] string1 = new String[arr.length];
		int hlp;
		
		for(int i=0;i<arr.length;i++){
			hlp=arr[i];
			string1[i]=input[hlp-1];
		}
		
		return string1;
	}
	
	public String[] shuffleR(int[] arr, String[] input)
	{
		String[] string1 = new String[input.length]; for(int i=0;i<input.length;i++) {string1[i]="";}
		
		for(int i=0;i<arr.length;i++) {
			int hlp=arr[i];
			for(int a = 0; a<input.length;a++) {
				string1[a]+=input[a].charAt(hlp-1);
			}
		}
		
		return string1;
	}
}
