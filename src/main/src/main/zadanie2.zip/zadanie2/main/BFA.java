package main;

import java.util.Scanner;
import java.io.*;

public class BFA {
	
	public Member2[] create(int length, String input) 
	{
		Member2[] member = new Member2[8]; 
		
		for(int i=0;i<8;i++){member[i]=new Member2(); member[i].input=input; member[i].length=input.length();}
		member[0].w_sw=true;member[1].w_sw=true;member[2].w_sw=false;member[3].w_sw=false;
		member[0].r_sw=true;member[1].r_sw=false;member[2].r_sw=true;member[3].r_sw=false;
		
		
		return member;
	}
	
	public static void rewrite(Member2 obj) 
	{
		Matrix matrix1 = new Matrix();
		String[] hlpstring; String string; 
		helpers h = new helpers();
		
		hlpstring = matrix1.matrix_W(obj.rownum, obj.colnum, obj.w_sw, obj.input);
		
		if(obj.r_c == true) {hlpstring=h.shuffleC(obj.shuffle, hlpstring);}
		if(obj.r_c == false) {hlpstring=h.shuffleR(obj.shuffle, hlpstring);}
		
		string=matrix1.matrix_R(obj.rownum, obj.colnum, obj.r_sw, hlpstring, obj.length);
		System.out.println(string);
		return;
	}

	
	/*Zakladna funkcionalita tejto metody bola prevzata zo stack-overflow*/
	private static void permuteW(Member2 obj, int[] arr, int index){
	    if(index >= arr.length - 1){ 
	        for(int i = 0; i < arr.length; i++){
	        	obj.shuffle[i]=arr[i];
	        }
	        rewrite(obj);
	        return;
	    }

	    for(int i = index; i < arr.length; i++){ 
	        int t = arr[index];
	        arr[index] = arr[i];
	        arr[i] = t;
	        permuteW(obj, arr, index+1);
	        t = arr[index];
	        arr[index] = arr[i];
	        arr[i] = t;
	    }
	}
	
	public static void permuteS(Member2 obj, int[] arr){
	    permuteW(obj, arr, 0);
	}
	
	
	
	public void basic(String input, int maxkey) throws FileNotFoundException
	{
		int length=input.length();
		Member2[] member = create(length, input);
		int[] array;
		
		PrintStream console = System.out;
		PrintStream o = new PrintStream(new File("log.txt"));
		System.setOut(o);
		
		for(int i=1;i<=length;i++){
			if((length % i) == 0){
				member[0].colnum=i;member[1].colnum=i;member[2].colnum=i;member[3].colnum=i;
				member[0].rownum=length/i;member[1].rownum=length/i;member[2].rownum=length/i;member[3].rownum=length/i;
			
			int r = member[0].rownum;
			array = new int[i]; for(int y=1;y<i+1;y++){array[y-1]=y;} //toto pole posluzi pre permutaciu stlpcov
			
			member[0].shuffle=new int[i]; member[1].shuffle=new int[i]; member[2].shuffle=new int[i]; member[3].shuffle=new int[i];
			member[0].r_c=true;member[1].r_c=true;member[2].r_c=true;member[3].r_c=true;
			
			if(i<=maxkey) {
			System.out.println("Pocet stlpcov: "+i);
			System.out.println("T,T:"); permuteS(member[0], array);
			System.out.println("T,F:"); permuteS(member[1], array);
			System.out.println("F,T:"); permuteS(member[2], array);
			System.out.println("F,F:"); permuteS(member[3], array);
			}
			member[0].shuffle=new int[r]; member[1].shuffle=new int[r]; member[2].shuffle=new int[r]; member[3].shuffle=new int[r];
			member[0].r_c=false;member[1].r_c=false;member[2].r_c=false;member[3].r_c=false;
			
			array = new int[r]; for(int y=1;y<r+1;y++){array[y-1]=y;} //toto pole posluzi pre permutaciu riadkov
			if(r<=maxkey) {
			System.out.println("Pocet riadkov: "+r);
			System.out.println("T,T:"); permuteS(member[0], array);
			System.out.println("T,F:"); permuteS(member[1], array);
			System.out.println("F,T:"); permuteS(member[2], array);
			System.out.println("F,F:"); permuteS(member[3], array);
			}
			}
		}
	}
}
